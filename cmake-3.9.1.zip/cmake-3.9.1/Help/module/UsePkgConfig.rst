.. cmake-module:: ../../Modules/UsePkgConfig.cmake
