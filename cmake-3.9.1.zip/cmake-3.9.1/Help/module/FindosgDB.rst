.. cmake-module:: ../../Modules/FindosgDB.cmake
