.. cmake-module:: ../../Modules/CPackWIX.cmake
