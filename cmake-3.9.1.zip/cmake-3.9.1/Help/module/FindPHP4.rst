.. cmake-module:: ../../Modules/FindPHP4.cmake
